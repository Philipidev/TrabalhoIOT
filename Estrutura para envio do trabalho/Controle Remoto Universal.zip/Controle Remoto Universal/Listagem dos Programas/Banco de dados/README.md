# BANCO DE DADOS
  Neste projeto foi utilizado um script em python que se conectava com o broker MQTT E registrava todas as transaçoes de dados num banco SQL local
